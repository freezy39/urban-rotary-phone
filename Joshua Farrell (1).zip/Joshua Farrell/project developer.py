class Developer:
    def __init__(self, problem_solving, adaptability, teamwork):
        self.problem_solving = problem_solving
        self.adaptability = adaptability
        self.teamwork = teamwork

    def __str__(self):
        return (f"Developer (Problem-Solving: {self.problem_solving}, "
                f"Adaptability: {self.adaptability}, Teamwork: {self.teamwork})")


class DeveloperBuilder:
    def __init__(self):
        self.problem_solving = 0
        self.adaptability = 0
        self.teamwork = 0

    def set_problem_solving(self, score):
        self.problem_solving = score
        return self

    def set_adaptability(self, score):
        self.adaptability = score
        return self

    def set_teamwork(self, score):
        self.teamwork = score
        return self

    def build(self):
        return Developer(self.problem_solving, self.adaptability, self.teamwork)


class Team:
    def __init__(self):
        self.members = []

    def add_developer(self, developer):
        self.members.append(developer)

    def __str__(self):
        return "Team Members:\n" + "\n".join(str(member) for member in self.members)


class Project:
    def __init__(self, name, status, team):
        self.name = name
        self.status = status
        self.team = team

    def __str__(self):
        return (f"Project: {self.name}\nStatus: {self.status}\n"
                f"{self.team}")


class ProjectBuilder:
    def __init__(self):
        self.name = "Untitled Project"
        self.status = "In Progress"
        self.team = None

    def set_name(self, name):
        self.name = name
        return self

    def set_status(self, status):
        self.status = status
        return self

    def set_team(self, team):
        self.team = team
        return self

    def build(self):
        return Project(self.name, self.status, self.team)


class Director:
    def construct_developer(self, builder):
        return builder.set_problem_solving(8).set_adaptability(9).set_teamwork(10).build()

    def construct_project(self, builder, team):
        return builder.set_name("AI Software Development").set_status("Ongoing").set_team(team).build()


# Demonstration of the Builder Pattern in action
if __name__ == "__main__":
    director = Director()

    # Creating developers using DeveloperBuilder via Director
    dev_builder1 = DeveloperBuilder()
    dev_builder2 = DeveloperBuilder()

    dev1 = director.construct_developer(dev_builder1)
    dev2 = director.construct_developer(dev_builder2)

    # Creating a team and adding developers
    team = Team()
    team.add_developer(dev1)
    team.add_developer(dev2)

    # Creating a project using ProjectBuilder via Director
    project_builder = ProjectBuilder()
    project = director.construct_project(project_builder, team)

    # Printing the project details
    print(project)
