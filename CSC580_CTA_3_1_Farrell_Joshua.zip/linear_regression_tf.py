import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

# TF v1 style
tf.compat.v1.disable_eager_execution()

# Reproducibility
np.random.seed(101)
tf.compat.v1.set_random_seed(101)

# -----------------------------
# 1) Generate random linear data
# -----------------------------
x = np.linspace(0, 50, 50)
y = np.linspace(0, 50, 50)

x += np.random.uniform(-4, 4, 50)
y += np.random.uniform(-4, 4, 50)

n = len(x)

# Plot training data
plt.figure()
plt.scatter(x, y)
plt.title("Training Data (Noisy Linear)")
plt.xlabel("x")
plt.ylabel("y")
plt.tight_layout()
plt.savefig("training_data_plot.png", dpi=200)
# plt.show()

# -----------------------------
# Normalize data to prevent NaNs
# -----------------------------
x_mean, x_std = x.mean(), x.std()
y_mean, y_std = y.mean(), y.std()

x_norm = (x - x_mean) / x_std
y_norm = (y - y_mean) / y_std

# -----------------------------
# 2) Placeholders
# -----------------------------
X = tf.compat.v1.placeholder(tf.float32, name="X")
Y = tf.compat.v1.placeholder(tf.float32, name="Y")

# -----------------------------
# 3) Trainable variables
# -----------------------------
W = tf.Variable(tf.random.normal([], stddev=0.1), name="weight")
b = tf.Variable(tf.random.normal([], stddev=0.1), name="bias")

# -----------------------------
# 4) Hyperparameters
# -----------------------------
learning_rate = 0.01
training_epochs = 1000

# -----------------------------
# 5) Hypothesis, cost, optimizer
# -----------------------------
y_pred = W * X + b
cost = tf.reduce_mean(tf.square(y_pred - Y))  # MSE

optimizer = tf.compat.v1.train.GradientDescentOptimizer(learning_rate=learning_rate)
train_op = optimizer.minimize(cost)

# -----------------------------
# 6) Train in a session
# -----------------------------
cost_history = []

with tf.compat.v1.Session() as sess:
    sess.run(tf.compat.v1.global_variables_initializer())

    for epoch in range(1, training_epochs + 1):
        # IMPORTANT: fetch BOTH train_op and cost so c is not None
        _, c = sess.run([train_op, cost], feed_dict={X: x_norm, Y: y_norm})
        cost_history.append(c)

        if epoch % 100 == 0:
            print(f"Epoch {epoch}/{training_epochs}  cost={c:.10f}")

    final_W, final_b, final_cost = sess.run([W, b, cost], feed_dict={X: x_norm, Y: y_norm})

    # Convert learned params back to original scale:
    # y_norm = W * x_norm + b
    # y = y_std * y_norm + y_mean
    # => y = (y_std*W/x_std)*x + (y_std*b + y_mean - (y_std*W/x_std)*x_mean)
    slope = (y_std * final_W) / x_std
    intercept = (y_std * final_b) + y_mean - slope * x_mean

    print("\nFinal Training Results")
    print(f"Final cost (MSE, normalized): {final_cost}")
    print(f"Learned weight (W, normalized): {final_W}")
    print(f"Learned bias (b, normalized): {final_b}")
    print(f"Unscaled slope: {slope}")
    print(f"Unscaled intercept: {intercept}")

    # -----------------------------
    # 8) Plot fitted line over data
    # -----------------------------
    plt.figure()
    plt.scatter(x, y, label="Training data")

    x_line = np.linspace(x.min(), x.max(), 200)
    y_line = slope * x_line + intercept
    plt.plot(x_line, y_line, label="Fitted line")

    plt.title("Linear Regression Fit (TensorFlow)")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.tight_layout()
    plt.savefig("fitted_line_plot.png", dpi=200)
    # plt.show()

# -----------------------------
# Cost curve plot
# -----------------------------
plt.figure()
plt.plot(range(1, training_epochs + 1), cost_history)
plt.title("Training Cost Over Epochs")
plt.xlabel("Epoch")
plt.ylabel("MSE Cost (normalized)")
plt.tight_layout()
plt.savefig("cost_curve.png", dpi=200)
# plt.show()

print("\nSaved files:")
print("training_data_plot.png")
print("fitted_line_plot.png")
print("cost_curve.png")
print("\nProgram complete.")