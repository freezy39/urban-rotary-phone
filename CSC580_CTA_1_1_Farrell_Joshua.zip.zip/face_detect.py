"""
CSC580 - Module 1 Critical Thinking Assignment
Face Detection using OpenCV Haar Cascade
Student: Jash Farrell
"""

import cv2
from PIL import Image
import os


def main():
    image_path = r"C:\Users\jash.farrell\OneDrive - Exxel Outdoors\Pictures\Screenshots\concert.png"
    output_path = r"C:\Users\jash.farrell\OneDrive - Exxel Outdoors\Documents\concert_faces_detected.png"
    cascade_path = "haarcascade_frontalface_default.xml"

    if not os.path.exists(image_path):
        raise FileNotFoundError("Image file not found.")

    if not os.path.exists(cascade_path):
        raise FileNotFoundError("Haar cascade XML file not found.")

    face_cascade = cv2.CascadeClassifier(cascade_path)

    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Improve contrast (important for concert lighting)
    gray = cv2.equalizeHist(gray)

    # More aggressive detection settings
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.03,
        minNeighbors=3,
        minSize=(15, 15)
    )

    print(f"\nFound {len(faces)} face(s) in this picture.\n")

    for i, (x, y, w, h) in enumerate(faces, start=1):
        print(f"Face {i} -> Top: {y}, Left: {x}, Bottom: {y+h}, Right: {x+w}")
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 0, 255), 3)

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(image_rgb)

    pil_image.save(output_path)
    pil_image.show()

    print(f"Annotated image saved to: {output_path}")
    print("Program complete.")


if __name__ == "__main__":
    main()
