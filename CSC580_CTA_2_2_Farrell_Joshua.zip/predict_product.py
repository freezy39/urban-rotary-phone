import pandas as pd
from keras.models import load_model

# Load trained model
model = load_model("trained_model.h5")

# Load the new product row
X = pd.read_csv("proposed_new_product.csv").values

# Predict scaled earnings
prediction = model.predict(X, verbose=0)
prediction = prediction[0][0]

# Rescale back to dollars using your scaler output:
# scaled = (raw * 0.0000036968) + (-0.115913)
# raw = (scaled - (-0.115913)) / 0.0000036968
prediction = (prediction - (-0.115913)) / 0.0000036968

print("Earnings Prediction for Proposed Product - ${}".format(prediction))
