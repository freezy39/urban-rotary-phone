import pandas as pd
from keras.models import Sequential
from keras.layers import Dense

# -----------------------
# LOAD TRAINING DATA
# -----------------------
training_data_df = pd.read_csv("sales_data_training_scaled.csv")

X = training_data_df.drop('total_earnings', axis=1).values
Y = training_data_df[['total_earnings']].values

# -----------------------
# DEFINE MODEL
# -----------------------
model = Sequential()

# 9 inputs → dense layers
model.add(Dense(64, input_dim=9, activation='relu'))
model.add(Dense(32, activation='relu'))

# output layer
model.add(Dense(1, activation='linear'))

# compile model
model.compile(loss='mean_squared_error', optimizer='adam')

# -----------------------
# TRAIN MODEL
# -----------------------
model.fit(
    X,
    Y,
    epochs=50,
    shuffle=True,
    verbose=2
)

# -----------------------
# LOAD TEST DATA
# -----------------------
test_data_df = pd.read_csv("sales_data_testing_scaled.csv")

X_test = test_data_df.drop('total_earnings', axis=1).values
Y_test = test_data_df[['total_earnings']].values

# -----------------------
# EVALUATE MODEL
# -----------------------
test_error_rate = model.evaluate(X_test, Y_test, verbose=0)
print("The mean squared error (MSE) for the test data set is: {}".format(test_error_rate))

# -----------------------
# SAVE MODEL
# -----------------------
model.save("trained_model.h5")
print("Model saved to disk.")
